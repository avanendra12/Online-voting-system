function myFunction() {
    alert('Result Out Now !');
  }